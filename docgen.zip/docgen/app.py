"""
Streamlit UI for docgen: upload two samples, optional CURL, run pipeline step-by-step.
Live UI: see sections → prompts → field values → draft building section by section → final draft + download.
Uses .env from backend folder.
"""
import sys
from pathlib import Path
from io import BytesIO

_root = Path(__file__).resolve().parent.parent
_docgen = Path(__file__).resolve().parent
for p in (str(_root), str(_docgen)):
    if p not in sys.path:
        sys.path.insert(0, p)

import streamlit as st

from docgen.sectioner import divide_into_sections
from docgen.extractor import extract_sections_from_docs
from docgen.section_prompt_generator import generate_prompt_and_fields
from docgen.field_fetcher import (
    call_chat_api_with_question,
    call_chat_api_with_question_debug,
    fetch_all_fields_via_chat,
    fetch_broad_answers,
    normalize_chat_api_input,
    _default_question_for_field,
    BROAD_QUESTIONS,
)
from docgen.question_generator import generate_questions_for_fields
from docgen.section_generator import generate_section
from docgen.assembler import assemble

# -----------------------------------------------------------------------------
# Config & helpers
# -----------------------------------------------------------------------------

st.set_page_config(page_title="DocGen – Section-based Draft", layout="wide")
st.title("Document Generator (Section-based)")

OLE_MAGIC = b"\xd0\xcf\x11\xe0"


def file_to_text(data: bytes, filename: str) -> str:
    """Extract plain text from uploaded file (.txt or .docx)."""
    if data.startswith(OLE_MAGIC):
        raise ValueError("Legacy .doc is not supported. Use .docx or .txt.")
    name = (filename or "").lower()
    if name.endswith(".docx"):
        from docx import Document
        doc = Document(BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252")


def text_to_docx_bytes(text: str) -> bytes:
    """Build a .docx in memory from plain text (paragraphs split on double newline)."""
    from docx import Document
    doc = Document()
    for block in (text or "").split("\n\n"):
        block = block.strip()
        if block:
            doc.add_paragraph(block.replace("\n", " "))
    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()


# -----------------------------------------------------------------------------
# Sidebar: inputs
# -----------------------------------------------------------------------------

with st.sidebar:
    st.header("Inputs")
    sample1 = st.file_uploader("Sample document 1", type=["txt", "docx"], key="s1")
    sample2 = st.file_uploader("Sample document 2", type=["txt", "docx"], key="s2")
    st.markdown("---")
    st.subheader("API / CURL (for field data)")
    curl_input = st.text_area(
        "Paste CURL command (chat-with-case API)",
        height=120,
        placeholder="curl 'https://...' -H 'authorization: Bearer ...' --data-raw '{\"content\":\"...\"}'",
        help="Optional. We call this API per field and with broad questions for maximum info.",
    )
    extra_context = st.text_area(
        "Extra context / case summary",
        height=100,
        placeholder="Optional: case summary or extra data if not using API.",
    )
    st.caption("Uses backend/.env for Azure OpenAI.")


# -----------------------------------------------------------------------------
# Run pipeline step-by-step with live UI
# -----------------------------------------------------------------------------

def run_pipeline():
    if not sample1 or not sample2:
        st.error("Please upload both sample documents.")
        return
    try:
        s1 = file_to_text(sample1.read(), sample1.name or "")
        sample1.seek(0)
        s2 = file_to_text(sample2.read(), sample2.name or "")
        sample2.seek(0)
    except Exception as e:
        st.error(f"Could not read files: {e}")
        return

    curl_str = (curl_input or "").strip()
    ctx = (extra_context or "").strip()

    # ----- Step 1: Identify sections (name + purpose only) -----
    st.subheader("Step 1: Identify sections")
    st.caption("Logical sections are identified from both documents. Full text is extracted in Step 2 in small chunks so nothing is truncated.")
    try:
        blueprint = divide_into_sections(s1, s2)
    except ValueError as e:
        st.error(str(e))
        return
    sections_list = blueprint["sections"]
    st.success(f"Identified {len(sections_list)} sections.")
    for i, sec in enumerate(sections_list, 1):
        st.markdown(f"**{i}. {sec.get('name', '?')}** — {sec.get('purpose', '') or '(no purpose)'}")

    # ----- Step 2: Extract section text (chunked so full doc content fits) then generate prompts -----
    st.subheader("Step 2: Extract section text and generate prompts")
    st.caption("Extracting text for each section in small chunks so the whole document is used without truncation. Then building prompts.")
    bar = st.progress(0, text="Extracting from document 1...")
    extracted_samples = extract_sections_from_docs(s1, s2, sections_list)
    bar.progress(0.5, text="Building prompts...")
    section_prompts_list = []
    for i, sec in enumerate(sections_list):
        bar.progress(0.5 + 0.5 * (i + 1) / len(sections_list), text=sec["name"])
        sample_text = extracted_samples[i] if i < len(extracted_samples) else ""
        section_prompts_list.append(
            generate_prompt_and_fields(sec["name"], sec.get("purpose", ""), sample_text)
        )
    bar.progress(1.0, text="Done.")
    st.success("Prompts and required fields ready.")
    with st.expander("View extracted sample text for each section (how extraction worked)"):
        st.caption("Section text was extracted in chunks (a few sections per call) so the full document content is used and nothing is truncated.")
        for i, sec in enumerate(sections_list):
            sample_text = extracted_samples[i] if i < len(extracted_samples) else ""
            with st.expander(f"{i + 1}. {sec['name']} — {len(sample_text)} chars"):
                if sample_text:
                    st.text_area(
                        "Extracted text",
                        value=sample_text,
                        height=min(400, max(120, 80 + sample_text.count("\n") * 18)),
                        key=f"extracted_sample_{i}",
                        disabled=True,
                        label_visibility="collapsed",
                    )
                else:
                    st.info("No text extracted for this section.")
    with st.expander("View prompt and required fields for each section"):
        for i, sec in enumerate(sections_list):
            info = section_prompts_list[i]
            st.markdown(f"### {sec['name']}")
            st.caption("Required fields: " + ", ".join(info.get("required_fields", [])))
            st.text(info.get("prompt", "")[:700] + ("..." if len(info.get("prompt", "")) > 700 else ""))

    # ----- Step 3: Fetch field values via API -----
    all_required = []
    seen = set()
    for i in range(len(sections_list)):
        for f in section_prompts_list[i].get("required_fields", []):
            if f and f not in seen:
                seen.add(f)
                all_required.append(f)

    field_values = {}
    if curl_str:
        st.subheader("Step 3: Fetching data via API")
        if all_required:
            with st.status("Generating questions for each field...", state="running"):
                field_to_question = generate_questions_for_fields(all_required)
            st.success(f"Generated {len(field_to_question)} questions.")
            with st.expander("Field → question used for API"):
                for f, q in field_to_question.items():
                    st.markdown(f"**{f}** → \"{q}\"")

            # One test request so user can see why answers might be empty
            first_field = all_required[0]
            first_question = field_to_question.get(first_field) or _default_question_for_field(first_field)
            debug = call_chat_api_with_question_debug(curl_str, first_question)
            with st.expander("API test (first request)"):
                st.caption(f"Question: \"{first_question}\"")
                if debug.get("error"):
                    st.error(debug["error"])
                st.code(f"Status: {debug.get('status_code')} | Response keys: {debug.get('response_keys', [])}")
                if debug.get("extracted_preview"):
                    st.success(f"Extracted: {debug['extracted_preview']}")
                else:
                    st.warning("No text could be extracted from the response. Check that your API returns a body with one of: content, answer, message, text, or choices[0].message.content.")

            status_placeholder = st.empty()
            progress = st.progress(0, text="Preparing...")

            def on_field_start(field_name: str, index: int, total: int):
                status_placeholder.markdown(f"**Fetching field {index} of {total}:** `{field_name}`")
                progress.progress(index / total, text=f"Fetching: {field_name} ({index}/{total})")

            field_values = fetch_all_fields_via_chat(
                curl_str, all_required, field_to_question, on_field_start=on_field_start
            )
            status_placeholder.markdown("**Done.** All fields fetched.")
            progress.progress(1.0, text="Done.")

        broad_status = st.empty()
        broad_progress = st.progress(0, text="Preparing broad questions...")

        def on_broad_start(key: str, index: int, total: int):
            broad_status.markdown(f"**Fetching {index} of {total}:** `{key}`")
            broad_progress.progress(index / total, text=f"Fetching: {key} ({index}/{total})")

        st.caption("Fetching additional information (broad questions)...")
        broad = fetch_broad_answers(curl_str, on_question_start=on_broad_start)
        broad_status.markdown("**Done.** Broad questions fetched.")
        broad_progress.progress(1.0, text="Done.")
        for k, v in broad.items():
            field_values[k] = v
        st.success("Fetched supplementary info.")
        with st.expander("Field → value (from API)"):
            for f, v in field_values.items():
                vstr = str(v)
                st.markdown(f"**{f}** → {vstr[:200] + '...' if len(vstr) > 200 else vstr or '(empty)'}")
    else:
        st.subheader("Step 3: Field data")
        st.info("No CURL provided. Using extra context only if provided.")

    if ctx:
        field_values["case_summary_or_context"] = ctx

    # ----- Step 4: Generate sections one by one (draft builds live) -----
    st.subheader("Step 4: Drafting section by section")
    st.caption("Draft updates below as each section is generated.")
    draft_placeholder = st.empty()
    draft_parts = []
    for i, sec in enumerate(sections_list):
        name = sec["name"]
        info = section_prompts_list[i]
        prompt = info.get("prompt", "")
        required_fields = info.get("required_fields", [])
        section_field_values = {f: field_values.get(f, "") for f in required_fields}
        for key, _ in BROAD_QUESTIONS:
            if field_values.get(key, "").strip():
                section_field_values[key] = field_values[key]
        if ctx:
            section_field_values["case_summary_or_context"] = ctx

        with st.status(f"Generating section {i + 1}/{len(sections_list)}: **{name}**", state="running"):
            text = generate_section(
                prompt, section_field_values,
                sample_text=extracted_samples[i] if i < len(extracted_samples) else "",
                section_name=name,
            )
            draft_parts.append(text)
        # Show growing draft after each section (unique key per iteration to avoid duplicate key error)
        current_draft = "\n\n".join(draft_parts)
        draft_placeholder.text_area(
            "Draft so far",
            value=current_draft,
            height=300,
            label_visibility="collapsed",
            key=f"draft_so_far_{i}",
        )

    # ----- Step 5: Assemble final draft -----
    # Pass ordered list so each section appears once (avoids repetition when blueprint has duplicate section names)
    final_draft = assemble(blueprint, draft_parts)

    st.session_state["docgen_final_draft"] = final_draft
    st.session_state["docgen_blueprint"] = blueprint
    st.session_state["docgen_sections_list"] = sections_list
    st.session_state["docgen_section_prompts"] = section_prompts_list
    st.session_state["docgen_draft_parts"] = draft_parts
    st.session_state["docgen_field_values"] = field_values

    st.success("Draft complete.")
    st.subheader("Final document draft")
    st.text_area(
        "Final draft",
        value=final_draft,
        height=420,
        label_visibility="collapsed",
        key="final_draft_area",
    )
    st.download_button(
        "Download as .docx",
        data=text_to_docx_bytes(final_draft),
        file_name="draft.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        type="primary",
        key="dl_final_run",
    )


# -----------------------------------------------------------------------------
# Main: run button + persisted final draft (after download/rerun)
# -----------------------------------------------------------------------------

if st.button("Run pipeline (analyze samples → generate draft)", type="primary"):
    run_pipeline()

# Final document draft and download (shown after run and persists after download/rerun)
if st.session_state.get("docgen_final_draft"):
    st.markdown("---")
    st.subheader("Final document draft")
    st.text_area(
        "Final draft",
        value=st.session_state["docgen_final_draft"],
        height=420,
        label_visibility="collapsed",
        key="final_draft_show",
    )
    st.download_button(
        "Download as .docx",
        data=text_to_docx_bytes(st.session_state["docgen_final_draft"]),
        file_name="draft.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        type="primary",
        key="dl_final_persisted",
    )
